# Szko-a
Platforma dla ochrony wizerunku szkoły i uczniów
